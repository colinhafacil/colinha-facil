# Colinha Fácil — Eleições 2026

PWA/mobile web app para organizar uma anotação pessoal de números de candidatos na ordem oficial de votação.

## Fonte dos dados
Os dados de candidaturas e fotos são importados no build a partir do Portal de Dados Abertos do TSE, conjunto **Candidatos - 2026**: https://dadosabertos.tse.jus.br/dataset/candidatos-2026

O aplicativo é independente do TSE e não indica candidatos.

## Build

```bash
npm install
npm run build
npm run dev
```

O build executa `scripts/import-tse.mjs` antes do Vite. O importador grava os dados em `public/data/` e as fotos em `public/fotos/`.

Se a base oficial não puder ser baixada ou retornar poucos registros, o build falha de propósito, evitando publicar um site vazio.


## V10
- Impressão otimizada para colinha compacta de 50 mm x 100 mm (5 cm x 10 cm).
- A tela normal continua igual; somente a impressão usa o formato compacto.

## Estatísticas privadas
A versão inclui `/admin.html` para consulta de estatísticas agregadas. Configure na Vercel as variáveis `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN` e `ADMIN_STATS_TOKEN`. O painel exige o token e não registra identidade de usuários.

A coleta de eventos deve ser descrita na política de privacidade do site. Não armazenamos nome, telefone, e-mail ou identificador do usuário junto das escolhas.
