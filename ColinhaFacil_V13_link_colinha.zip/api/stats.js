function redisConfig(){
  const url=process.env.UPSTASH_REDIS_REST_URL;
  const token=process.env.UPSTASH_REDIS_REST_TOKEN;
  if(!url||!token) throw new Error('Armazenamento de estatísticas não configurado.');
  return {url:url.replace(/\/$/,''),token};
}
async function redis(command){
  const {url,token}=redisConfig();
  const r=await fetch(`${url}/${command.map(encodeURIComponent).join('/')}`,{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok) throw new Error(`Redis HTTP ${r.status}`);
  return r.json();
}
function json(res,status,data){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}})}
function validEvents(events){
  if(!Array.isArray(events)||events.length>50) return null;
  const out=[];
  for(const e of events){
    if(!e||typeof e.cargo!=='string'||typeof e.numero!=='string'||!/^\d{2,5}$/.test(e.numero)) continue;
    if(!['depFederal','depEstadual','senador1','senador2','governador','presidente'].includes(e.cargo)) continue;
    out.push({cargo:e.cargo,numero:e.numero});
  }
  return out;
}
export default async function handler(req){
  try{
    if(req.method==='POST'){
      const body=await req.json().catch(()=>({}));
      const events=validEvents(body.events);
      const kind=['created','downloaded','shared'].includes(body.kind)?body.kind:null;
      if(!events||!kind) return json(req,400,{error:'Dados inválidos.'});
      const commands=[['INCRBY','cf:stats:total:'+kind,'1']];
      for(const e of events) commands.push(['INCRBY',`cf:stats:${kind}:${e.cargo}:${e.numero}`,'1']);
      for(const c of commands) await redis(c);
      return json(req,200,{ok:true});
    }
    if(req.method==='GET'){
      const auth=req.headers.get('authorization')||'';
      const expected=process.env.ADMIN_STATS_TOKEN;
      if(!expected||auth!==`Bearer ${expected}`) return json(req,401,{error:'Não autorizado.'});
      const keys=await redis(['KEYS','cf:stats:*']);
      const list=Array.isArray(keys.result)?keys.result:[];
      const values={};
      for(const key of list){
        const v=await redis(['GET',key]);
        values[key]=Number(v.result||0);
      }
      return json(req,200,{values,generatedAt:new Date().toISOString()});
    }
    return json(req,405,{error:'Método não permitido.'});
  }catch(err){
    console.error(err);
    return json(req,500,{error:'Serviço de estatísticas indisponível.'});
  }
}
