# Colinha Fácil — Paraná 2026

PWA para organizar a colinha eleitoral escolhida pelo próprio usuário.

- Base de candidaturas: TSE / Dados Abertos
- Atualização da base durante o build do Vercel
- Fotos oficiais do TSE quando disponíveis
- Ordem oficial de votação
- Botão CONFIRMA visual na colinha
- Limpar tudo
- Compartilhar / WhatsApp / baixar / imprimir

O Colinha Fácil não indica candidatos.
